//
//  AppDelegate.swift
//  test
//
//  Created by Sébastien Portrait on 11/07/2019.
//  Copyright © 2019 Sébastien Portrait. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {



    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }


}

