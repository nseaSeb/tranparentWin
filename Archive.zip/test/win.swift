//
//  win.swift
//  test
//
//  Created by Sébastien Portrait on 12/07/2019.
//  Copyright © 2019 Sébastien Portrait. All rights reserved.
//

import Cocoa

class win: NSWindowController {

    override func windowDidLoad() {
        super.windowDidLoad()
        self.window?.isOpaque = false
        self.window?.backgroundColor = .clear
        // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
    }
    
}
