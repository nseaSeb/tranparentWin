//
//  ViewController.swift
//  test
//
//  Created by Sébastien Portrait on 11/07/2019.
//  Copyright © 2019 Sébastien Portrait. All rights reserved.
//

import Cocoa

class ViewController: NSViewController, NSApplicationDelegate {

    
    override func viewDidLoad() {
        super.viewDidLoad()
 
    
        self.view.layer?.backgroundColor = CGColor(red: 0, green: 0, blue: 0, alpha: 0.7)
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
       
            
        }
    }


}

